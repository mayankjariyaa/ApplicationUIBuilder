-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 07, 2026 at 04:32 AM
-- Server version: 10.6.23-MariaDB-cll-lve
-- PHP Version: 8.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pluginDashboardDataBase`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `role_id`, `status`, `created_at`) VALUES
(1, 'infinian_admin', '$2y$12$4DkAjxYGG/zy5pcFOlB9Y.9wuQqCEM.3cG.ynalpGsejvHfMQaeaa', 1, 'active', '2026-01-06 22:15:51'),
(2, 'admin', '$2y$12$4DkAjxYGG/zy5pcFOlB9Y.9wuQqCEM.3cG.ynalpGsejvHfMQaeaa', 1, 'active', '2026-01-06 23:15:42');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `domain` varchar(150) DEFAULT NULL,
  `api_key` varchar(64) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `components_master`
--

CREATE TABLE `components_master` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `default_json` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `page_type` enum('home','landing','service','product','custom') DEFAULT NULL,
  `status` enum('draft','published') DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `page_routes`
--

CREATE TABLE `page_routes` (
  `id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `method` enum('GET') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `page_versions`
--

CREATE TABLE `page_versions` (
  `id` int(11) NOT NULL,
  `page_id` int(11) DEFAULT NULL,
  `ui_json` longtext DEFAULT NULL,
  `seo_json` text DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`) VALUES
(1, 'admin'),
(3, 'developer'),
(2, 'manager'),
(4, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `key_name` varchar(100) DEFAULT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ui_screens`
--

CREATE TABLE `ui_screens` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `schema_json` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `api_key` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ui_screens`
--

INSERT INTO `ui_screens` (`id`, `name`, `schema_json`, `created_at`, `api_key`) VALUES
(1, 'demo', '[{\"type\":\"heading\",\"value\":\"mayank\"}]', '2026-01-07 10:46:12', '123'),
(2, 'Demo2', '[{\"type\":\"heading\",\"value\":\"Demo Heading\"},{\"type\":\"text\",\"value\":\"this conetent for checking purpose\"},{\"type\":\"image\",\"value\":\"data:image\\/jpeg;base64,\\/9j\\/4AAQSkZJRgABAQAAAQABAAD\\/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys\\/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N\\/\\/AABEIAJQBBgMBIgACEQEDEQH\\/xAAcAAABBQEBAQAAAAAAAAAAAAADAAIEBgcFAQj\\/xABPEAABAwMBAwUJCwcKBwAAAAABAAIDBAURBhIhMQcTQVFxFCIyQmFygZHBFTM0NVJzgqGxstEWIyRikpPhFyUmNkNERXSEtAhTVGNkg8L\\/xAAZAQACAwEAAAAAAAAAAAAAAAACAwABBAX\\/xAAoEQACAgEDAQgDAQAAAAAAAAAAAQIDEQQSMTIFExUzQVFSYSE0cSP\\/2gAMAwEAAhEDEQA\\/AMZARAF41qK1qekIbE1qK1qTWorWpqQtsTWorWpNajMamqIpyPGsRWsTmtRmMToxFOQxrEZrE9rEVrE2MBTkDaxEazcitYnhiaoi3IEGJwYjBnkTg1HtA3Adhe7CkbCQYi2lbgGwvdhH2V7sqbStxGMaWwpGylsqbSbiKWLwsUrYTC1VtL3EYtTSxSS1NLEO0LcRXMQy1S3MQ3MQOIakRS1DLVKcxDc1A4hqRGcE0hGLUxwS2g0wBCaQjEJjggaGJgSEkTCSDBZyGhFaF40IzQs6Q9s9a1FY1Na1HY1OihTZ61qO1q8Y1SGNToxEyYmsRmMXrGo7G71ojETKQ1rEVrE9rEVrU6MRUpDA1PDU8NRA1MURTkDDU7YRQ1ODUWANwENTg1G2UtlXgrcB2PIlso2ylsqYKyA2V5sqRsrzZVYL3EfZXhapBG5NLVMBZI5amFqkFqaWoWi0yO5qG5qklqG5qBoYmRXNQ3NUpzUJzUEkMTIjmobgpTmoLglNDEyOQmEI7whEJTQxMGQknELxDgPJzGhFYE1oRmBZ0hzY9gR2NTGNR2N8idFCZMIxqkMahxt6VKY1aoRRnk2esajtavGNRgMJ8YiJMTWozWpMbuRWhMSFOQ0NTw1ODU8NCYkL3DA1ODU\\/C9AV4KyMAXoan4XuFeCsjNleYRMJYUKyCwvMImF4QqwXkGQm7KLhNIUwXkEQmEI5CYQgaCyBIQ3BHI3JjgqaDTI7ghOCkOCG4JbQxMiuCE4KS4ILglNDYsjOCEQpDgguHUktDUwRCS9KSXgYmc1oR2BDYEeMJMR0gsYXUobZUVJbhuwwnG0\\/8FEoG5qofPCuUIzM3PHaH2obrnXhRLpqVmcnWj5M3uja5l1AJaCQYeH1p38mdYPBudOfOicPatGp24hZ5oRgkLV2r1HvTVP0MyPJ1dh4NVRv9Lh7E08n98Z4PcbuyY\\/gtTDU7A4Ji19yFvQ0syg6Iv7OFLE\\/zZ2+1DdpG\\/R8ba8+bIw+1a32Bet9CNdo3euAH2dU+DFauhqqGbma2nfBKW7QY\\/iR17kHGOO7tVs5SPjqnA\\/6UfecuhoWz0UrZn1VPFO4saRzrdoN48AV0nrFCiNkl+WcxaNzvlXF8FFABTgFsTrBZ3cbXSfugvDp2zH\\/AAyl\\/YSPFYfEd4XZ8kY9hIDctedpqyn\\/AA2AdgKG7S1idxt0foc4e1X4pD4sp9l2fJGS4yUsLTLvpayw2yqlgogySOJzmuD3biPSqDZKFtyudNRyPcxszsFzeI3ZWqjVwthKeODLdpJ1SUW\\/yyBhIhaUOT+29NTVftBPHJ\\/af+bVftj8ErxKj7HeG3\\/RmBCaR0rUvyAs3yqv97\\/BIaDsrTnZqT2y\\/wAEPidH2Euzbvoywjd5EwjctMumkLNTUE0jIpmua3IdzpyFR225sd7p6KZwkjkkZkjdtNcfqTKtZVbnHoBbo7asZ9TkOCGRuWxjRdhG7uAHtkf+K9\\/JCxMGBbIT2lx+0rN4nX7M0Ls2z3MXfu4oTseT1rbDpmzMGW2ym\\/d5QX2K1M4Wyj\\/cNPsQvtKD4iMXZ01zIxN2OsIJwRuIW2OttDH73QUjeyBo9iq2t6Gnlt73iJjHwRmRpYwDhx9YQLXKUsYDeicY5yZs8IJG9SHBBcFpkZ4gSN6Sc4JIAznMCkMCEwIzEiI2RNt+6rh88ZwrDZ6mpfcTDVuidkuMWw3Bw2TZOfW31qv0HwuDzwu7a\\/jmh3ce68\\/vmLPq+UadLwzdIm\\/m2dgUa72+ouFKIaS51Nul2sianDSTu4EOByFNYNw7AiNG8LGaj56pdYaxGq4rFJqSfHukKJ0ghidj87sFwBb6VqV2tetrdSvqLRqQXKWIE9yVlDE0SdhYAc+lYvCc8qkZ6TqIf7lfT\\/FQhnmgOUqm1NUC23GnFFdMbmB2WTEDfs53g8e9+1aC0L5k5QmO0\\/yjXWS3ExSQVbaqIjxXOa2X1ZcfRuX0vQTiqoqeoHCaJsnrGVCGfcpHx5AP\\/FH3nLt8n0vOirbsOaIdhm0eD93EeTfj0Li8o4zfYf8AKt+85drk6dtR1g+SRldLUfq1nN0\\/7VhcVm2ruU2s0nWspbtp0\\/nWl8UkVSHNe0HeRuWkrDP+Iz4ys3T+izcfOauadJGksvuoZaBlbFppkjHxCVjI65u04EZAAI4o+idTt1Vapq5tFJRmKpfTuilOXAtDSc+v6lXq\\/X9ps+k6COir4Jrk+CCGGAd9hxDQcjqCu9Db6SgdUuo4Wxd1Tmom2ScPkcAC7fwzgZx05PElQgy+fE1b8w77Fmejv6yW\\/wA8\\/dK0u+fE1b8w77Fmmj\\/6x24\\/r\\/8AyV1tD+vYcnXfsVmkakvvuBQmtkt9XVQMDnSup2g820dJGc47OpcLTXKVaNQXmK1U8FVBUStc5nPsABwM47cZPoVovTA6z1wPA08mf2SsJv8ATSaevGnb\\/Sgt5ylp6jI8ZzAA9v0m7vSuSdY3a9XOGz2qpuNQHOigZtlrPCd1AeUnCqFn5SoL3Xdx2yyXCeYDacNqMBo6ySV1b\\/JHea+x22B4fTzvFdKQeMUeHN9byz1LPuRkH8pqouzk0p6f1lCGmauk5nTldNjeyIuxlZbb6ruy9W6ff76xuCOpxC1HW4\\/orcvmSse0m8vmtjnYz3R1f9wrbout\\/wAZi1vQv6jfcblx9Uajtumbf3XcpCNo7MUTRl8juoD29C7B4LBeUmsku2uJaeRxMVO9lOxvQBuLvXlYjYaJbb7qi90AuNDp+jgppBtQMq6wtklHWQGkN9ZUOw67o7pc32e6Ur7XdmPMZp5XBzXOHitd0nG8ZxlaBDDHDCyGNuyxjQ1o6gNwWDct1EKbWEVTFmN1RTNdtsOHB7SRtA9fDf5AoWazMzpVP1s\\/m7fUNxnbgcFY9PV8l301arjP7\\/U0rHy4GAX4w4+sFVnXw\\/RQOtjgjr61\\/QLOhmav6UF6M\\/7UF3Fd2RxogiEl6UkoM57FIYua2rb1FGZXM6is8ZxNDhI7VvGauHzwu3Zu\\/vFEeoVR9c7B+KrNqrGSXGmZg75Arbp6lqIa4yVMkLsyYi5rO5peXHOekkgfRWbVSUmsGjSxaTybmzwW9g+xEb4Q7UNnAdgUG9VtyoqZr7PaRcqhzsc2alsLWDrJPsCymk+cqXfyoQk8fygH+5X1FjPrXz9Fyba5F6F3ZR0LKptX3WA6qaWh+3t8OrK02rk1\\/caJ1PDRWa0ySAtfVGrfM5vWWNDcZ7SoQxnXQk1Nyl3SntwMj6isFLHgbssa2MnsGwT6F9KUkApqaGBu9sTGsHoGFUdDcnlt0m41bpn11zcCH1Uoxs54hjd+M9JJJ8vQrlkHoUIZ1yj\\/AB5F\\/lW\\/ecuxyc42K7Hyhn61VeVe6NotRwMe1zs0TXbvPerNybhjYKuZr3kThkpDjkNJGMDyfxW++UXpq0YKK5LU2SZdulYZ\\/wARhBuVmHVSzfeatw2x1qgam5NINT1jKq8ahuMr2NLGNEcQawE7wAGrAbztVFgpdQaMoKKZkbHmmgfFLsAmN4a0gro0l7gq9Q11ngaXOoYY3zSh24PdnDMdYGCe1caj0tX0FvioabV12bBDGI4xsQktaBgDJb0exF0jpOl0vUXGoiuFXWzVzg+Z9TslxcMnOQB1qEO3e\\/ieu+Yd9izTR5\\/pHbvnPYVot\\/mEdiuDifBp3n6lkeg7yyp1XaogxwLpOP0SunopxVFiZzNbXKV9bRtN7kbHZq973YY2nkJPk2Ss61ZbmXHkrtFwi759DBFJn9QgNd7D6FetQWWk1DSdyVtRVMpyCHsp5zGJAeh2OPD61GtGkLXa7XU2uGWrmoKiJ0T6eeoc9oa7IOOriuYdM4fJNDUz2x1zrXbREbaSn8kTCT9p+oKq8jW7U1Tv\\/ux+8tPGnaaKywWiinq6KmhGGmnmIeR0guOSeK4lBycWy11Lam23C6UsrRs7cczd46jlu9Qh2Nb\\/ANVrj80VjmlBsz28dVRu\\/eFbBrfH5K3BriSDFg71idmr46W8W2kjjIBnYRjyv3rXo5KM3n2Zk1kXKCx7o+ijwWFcplumtOsn1rmnmalzaiN2NxIxtD0YHrW69BXNvtjoL\\/ROo7nAJYs5aQcOYetp6CshrJ1LUMqqaKohcDHKwPafId6wrlpq+7dYR0lODM+CBkTWM3l0jznZ7fB9a0ai0rf7PSOorLqvmqQZ5ttXQNmfF5A4Pbu7QmWDQltslfJdampnud0eS81NTjvSeJa0cD5Tv8qhCbY7c6zacttte7afS0zI5COBfjvsfSyqrr\\/4OzqLXK71EjTkZ4qj8oDmi3PefEje4ehHW8TQM1mLM0fwQXKG65g471yG64j5Ll2XbE5CqkTCkoHug35LkkvvYh93I5ATwmBPCwI3EuglbT1kMzvBY\\/J3K\\/WO501TPCYJWvAe3IHEb+lZ9Bvkb2qfFA18zHsLo5MgB7Dgjel28h1cH0z3awcTjcF77oRjg8LCzQ1L\\/fLvcXf6gj7E02hrvfKyvf51U\\/8AFKGm6G6wt4yN9aE+90bB39RG3teAsQ9xKQ+Hzzh+tK4+1efk\\/a85NGxx\\/W3qENok1PbGeFXUze2Vv4qJLrexReHd6Jv\\/AL2\\/islFktjN4ooB9FGbbaJvg0kI+gFCDuUq8Ud9v8NTQVMdRCykbGXxuy3Ic44yO1S9I6wuFmhmhNvfXNIaGvikawtA6Dnj6FWLzFHDW7MbQ1pYNzRjrU7Tji4Th3RgBabPKiIr82ReP5R7ieGn5x21LF4eUS6nhYD6apv4LgncM7\\/QoL7vbo3Fr6yEEcQXLMPLSeUK9HhYmD\\/Vj8EJ+v76fBs9OB5ar+CrPu1bdnIqo3DrbvRKSvpK1zu5Z2yFvEBQh1rpra+1VuqKeW2U0ccsTmucJyS0Edip1innpLtSzUUrYqhjsxvczaAOOpd6uH6HL5pVetPxhB5y10dEjLd1ovkeo9V+LcqT00v4FSGal1gD3tfb\\/TTO\\/FcS4VxoIud5iSVnjFnir23XmKrppKkwzQwsbnbeNx7FkNR326q1i3+8Wx3bE4e1J2rdY9PuW4djwuV7qQPoW1cLJJY3fIGSPQoMWprfUS83CJjJw2dgqEJuotV6mns1VDVR28RuZhxYXZVCtlRPDW004dzk7JWuaXcCQd3oVxv7tq0zEDi3KpNsdtSxHpMg+1Op6mJu4RrQ15qoOP8ANNA7f0VTh7ET+ULUjfDsNMfNrP4LlRncF7I9jGOfI8Na3iXcEkajpO5Rr54+nj9GqB9iBJyjXL+007U\\/RnYVwH3q3hxAqQ7HEtBIC9ZVQVTC6nlbIPId6hZ1X8olSfCsVcOySM+1VzVmrpbtSinZb6im2mkOdMW42fJg8UaRcS+HvGq48op8Mrp4BMKcU0razIeFeL0rxCWACcEwJ4QIMPCe\\/Cn2x7jOGuO\\/a3di58PhhTrb8MZ2pVoysvLd4CBXVjKKMPfHI\\/zG5wjRnvR2L2X3p\\/mlLGFfOraPb2WQSudnAAUp96miYJJbdMyPiXZBVNpGj3bbkf2vQtJc0SR7LxlpG8FQhCt12pLg09zv74cWnip6zeoc623t5gOyGybsLRKaTnqeOX5QyoQ4F++HDzVK03\\/bKJfjmt9Cmac4SLRZ5SM9fmM7ZCout4o2VsZY0NJbgkK99BVI1uM1kfYkM0FioxSwWiCSWNgbsDO7imW62ikuE1RDgQzNzhcuS31M1sgdz7nNGDsqx0pzAwZBLQAQqINrvgkvYq7afh0farHXj9Ek7FXLX8OZ2rXT5cjLd1otNfjuGZuN2yeKr91rRS6aigZudIMbl3bg8No5ckb2qiVc5rqmCmG9rT7VkNRZ9JVD4aOSnm3AtLmLmaZcG36Xf0nG5dauj7kpYJGjZ2Bg4Vf07KPdxzgdxJUIW+\\/HNvkHHcqXah+dj89W+8OLqKTsVStzS2ZgPyk6rqYm3pRoUT+8HYFTtW3KWesFJG4tYNxAPFWpjvzYHkVD1Ax0V62jnBOQUkai522kggoImCNpy3vsjiqleXPs12EtK7ZY452QdyttNMHUsRHDZVR1k4OnZg7woWWKCoFVTslHSFyr370ETT+0Lc3P1pl53xjCuPJT4ZXTxKaU53EppK2mQaUkikhLIwTwhhPCWMYeE98FPtvw1nkK58HfOXStkZFUHHrS7A6y6xnvGpTn8y8\\/qlNiPeBMq5mR07y9wHelLGFApB\\/PY+cWkBwDM+TKzalcBduc37IerfXXbNPzdM0l5GNyhCp3Yd0XqQM39+tAoGmOjhZ0hoVdsdkeZ+6qod8d4yrQ3A4BQhW778MU+wDAJXPvh\\/TFP0+8Fp8i02L\\/ADRng13jO27c0nGcKmahpKu41bXMiOG9Kue0OsLzLektWfA\\/KODBNWx0jYWwbw3AJUixwVEfOuqc7TjuyuoXsHjBec7GD4Qx1ZUwyZQGu3Uj+xVy2fDm9q79wni7mcNsZVZgm5io5zqWuhPYzNc1vRarhRisi2C4tyOgrnUenaalqRM05I60xt9PyUQXxvSAkdzIb30Tp1sAqqd0RxvG5V+l0++kqRLFKQc710BeoTxwnC7056UPdy9gu8j7hK4F1KQ7e7GCq9G0NqmAda7FTcYXwuAdvXCjlzVNc47sp1UGm2xVs00ki5sP5sdi5N7tba9m03c9u8KXFWQljRtjOE\\/n4zwcEhxaY5NYONR1VTRQczNGTjhgLmVNFUXOs5x7CGAq0uMZ6Qe1MOyBgfUqwEAhiEEIY3oCgXUZZ6F0jvC5t1dsx7x0K48gy4K47j6UwpzuOfKmkrWZfU8XiWUkIRECe0pJJaGMkU26QLt0fvzEkkEwoFpi8AdiDVwRz4bICQkkljAUNqoxvEQypcdLDGctYAvUlCBcBOaMpJKEKzfvhah0tRJBujOMr1JdCPQYJdYd9fUAeGhmvqD46SStRRTbGmrnPF5TTUSni8pJI0kA5Ma6V7uLimJJIsYRWfyJNykkoUJJJJQiPMleZSSQhrgQke3g4p3dEo8cpJKmkRNnorJh46IK+oHjJJJUkhsWworp8+Eg11RJI07R4LxJKwsjM\\/g5hTUkkYA1JJJUEf\\/Z\"},{\"type\":\"button\",\"value\":\"View More\"}]', '2026-01-07 10:50:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `components_master`
--
ALTER TABLE `components_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `page_routes`
--
ALTER TABLE `page_routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `page_id` (`page_id`);

--
-- Indexes for table `page_versions`
--
ALTER TABLE `page_versions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_id` (`page_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ui_screens`
--
ALTER TABLE `ui_screens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `components_master`
--
ALTER TABLE `components_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_routes`
--
ALTER TABLE `page_routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_versions`
--
ALTER TABLE `page_versions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ui_screens`
--
ALTER TABLE `ui_screens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD CONSTRAINT `admin_users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `pages`
--
ALTER TABLE `pages`
  ADD CONSTRAINT `pages_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`);

--
-- Constraints for table `page_routes`
--
ALTER TABLE `page_routes`
  ADD CONSTRAINT `page_routes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  ADD CONSTRAINT `page_routes_ibfk_2` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`);

--
-- Constraints for table `page_versions`
--
ALTER TABLE `page_versions`
  ADD CONSTRAINT `page_versions_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
